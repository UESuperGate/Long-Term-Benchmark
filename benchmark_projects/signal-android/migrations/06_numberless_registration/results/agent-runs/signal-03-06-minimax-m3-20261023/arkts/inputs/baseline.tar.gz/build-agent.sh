#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
python3 "$root/_benchmark_scaffold/with_device_lock.py" --lock /tmp/long-term-benchmark-full-build.lock -- \
  "/Applications/DevEco-Studio.app/Contents/tools/hvigor/bin/hvigorw" --no-daemon --mode module -p module=entry@default assembleHap
