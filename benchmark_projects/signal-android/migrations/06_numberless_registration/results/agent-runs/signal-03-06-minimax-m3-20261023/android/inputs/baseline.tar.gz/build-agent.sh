#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
export EVALUATOR_SRC="$root/_benchmark_scaffold/evaluator-src"
export COMPILE_KOTLIN_SLICE="$root/_benchmark_scaffold/compile_kotlin_slice.sh"
python3 "$root/_benchmark_scaffold/with_device_lock.py" --lock /tmp/long-term-benchmark-android-full-build.lock -- \
  bash "$root/tools/build.sh" "$root" "$root/build/public"
