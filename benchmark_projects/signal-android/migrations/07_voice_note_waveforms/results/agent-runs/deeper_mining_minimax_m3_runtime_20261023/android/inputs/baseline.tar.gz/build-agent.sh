#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
export ANDROID_HOME="/Users/z1an/Library/Android/sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home"
export PATH="$JAVA_HOME/bin:$PATH"
test -x "$JAVA_HOME/bin/java" && test -x "$JAVA_HOME/bin/jlink"
test -x "/opt/homebrew/Cellar/openjdk@17/17.0.18/libexec/openjdk.jdk/Contents/Home/bin/java" && test -x "/opt/homebrew/Cellar/openjdk@17/17.0.18/libexec/openjdk.jdk/Contents/Home/bin/jlink"
python3 "$root/_benchmark_scaffold/with_device_lock.py" --lock /tmp/long-term-benchmark-android-full-build.lock --   "/Users/z1an/.gradle/wrapper/dists/gradle-8.14.3-bin/cv11ve7ro1n3o1j4so8xd9n66/gradle-8.14.3/bin/gradle" -Dorg.gradle.java.home="/opt/homebrew/Cellar/openjdk@17/17.0.18/libexec/openjdk.jdk/Contents/Home" -p "$root" --no-daemon --offline :app:assembleDebug
