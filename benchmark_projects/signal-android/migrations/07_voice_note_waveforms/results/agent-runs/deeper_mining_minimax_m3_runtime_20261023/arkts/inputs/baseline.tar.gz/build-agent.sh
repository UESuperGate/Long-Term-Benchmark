#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
export OHOS_BASE_SDK_HOME="/Users/z1an/Library/OpenHarmony/Sdk"
export JAVA_HOME="/Applications/DevEco-Studio.app/Contents/jbr/Contents/Home"
python3 "$root/_benchmark_scaffold/with_device_lock.py" --lock /tmp/long-term-benchmark-full-build.lock --   "/Applications/DevEco-Studio.app/Contents/tools/hvigor/bin/hvigorw" --mode module -p product=default -p module=entry@default assembleHap --no-daemon
