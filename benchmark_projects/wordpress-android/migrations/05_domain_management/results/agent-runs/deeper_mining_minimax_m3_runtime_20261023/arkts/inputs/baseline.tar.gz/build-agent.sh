#!/usr/bin/env bash
set -euo pipefail
"/Applications/DevEco-Studio.app/Contents/tools/hvigor/bin/hvigorw" --no-daemon --mode module -p module=entry@default assembleHap
