#!/usr/bin/env bash
set -euo pipefail
"/Users/z1an/.gradle/wrapper/dists/gradle-8.14.3-bin/cv11ve7ro1n3o1j4so8xd9n66/gradle-8.14.3/bin/gradle" -p . --no-daemon --offline assembleDebug
