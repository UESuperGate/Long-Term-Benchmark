#!/usr/bin/env bash
set -euo pipefail
python3 - "/tmp/long-term-benchmark-arkts-full-build.lock" '["/Applications/DevEco-Studio.app/Contents/tools/hvigor/bin/hvigorw", "--mode", "module", "-p", "product=default", "-p", "module=entry@default", "assembleHap", "--no-daemon"]' <<'PY'
import fcntl, json, subprocess, sys
lock_path, command = sys.argv[1], json.loads(sys.argv[2])
with open(lock_path, "a+") as stream:
    fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
    raise SystemExit(subprocess.run(command).returncode)
PY
