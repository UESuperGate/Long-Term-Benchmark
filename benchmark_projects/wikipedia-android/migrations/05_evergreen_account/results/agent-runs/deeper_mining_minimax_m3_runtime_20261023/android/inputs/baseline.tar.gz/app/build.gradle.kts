plugins { id("com.android.application"); kotlin("android") }

android {
    namespace = "org.wikipedia.benchmark.evergreen.base"
    compileSdk = 37
    defaultConfig {
        applicationId = "org.wikipedia.benchmark.evergreen.base"
        minSdk = 37
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
    }
    sourceSets {
        getByName("main") { kotlin.srcDirs("src/main/kotlin") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
