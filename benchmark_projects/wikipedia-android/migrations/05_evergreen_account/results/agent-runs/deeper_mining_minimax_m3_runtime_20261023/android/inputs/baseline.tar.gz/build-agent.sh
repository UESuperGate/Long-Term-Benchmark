#!/usr/bin/env bash
set -euo pipefail
python3 - "/tmp/long-term-benchmark-android-full-build.lock" '["/Users/z1an/.gradle/wrapper/dists/gradle-8.14.3-bin/cv11ve7ro1n3o1j4so8xd9n66/gradle-8.14.3/bin/gradle", "-p", ".", "--no-daemon", "--offline", ":app:assembleDebug"]' <<'PY'
import fcntl, json, subprocess, sys
lock_path, command = sys.argv[1], json.loads(sys.argv[2])
with open(lock_path, "a+") as stream:
    fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
    raise SystemExit(subprocess.run(command).returncode)
PY
