#!/usr/bin/env bash
set -euo pipefail
hvigorw="${HVIGORW:-/Applications/DevEco-Studio.app/Contents/tools/hvigor/bin/hvigorw}"
"$hvigorw" --mode module -p product=default -p module=entry@default assembleHap --no-daemon
