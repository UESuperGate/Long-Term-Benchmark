Implement 04_reading_lists completely in this arkts candidate.

Read `_benchmark_inputs/requirement.md` and `_benchmark_inputs/public_transitions.json`, inspect the visible production scaffold, and implement the requested behavior in real production code.

Rules:
- Work only in this candidate directory. Never inspect parent, sibling, home, benchmark, final, evaluator, report, or network paths.
- Subagents are allowed and inherit exactly the same workspace boundary.
- Do not create case-ID switches, marker facts, semantic projections, evaluator APIs, or source-observer shortcuts.
- Preserve unrelated behavior. Implement application-owned state, persistence, effects, UI/page wiring, failure recovery, and cleanup.
- Run `bash build-agent.sh` exactly as written and repair compilation within the overall task budget.

Finish with a concise summary of changed production files and remaining blockers.
